let inp16 = $("#inp16").value;
let inp8 = $("#inp8").value;
let inpNumber = $("#inpNumber").value;
let inpSymbols = $("#inpSymbol").value;

let hasil = generate();

console.log(hasil);

function generate() {
  randomPassword(inp16);
}

function randomPassword(length) {
  var chars = "abcdefghijklmnopqrstuvwxyz";
  var pass = "!@#$%^()_+<>?";
  var num = "123456789";
  var pass_baru = "";
  for (var x = 0; x < length; x++) {
    var i = Math.floor(Math.random() * chars.length);
    var j = Math.floor(Math.random() * pass.length);
    var k = Math.floor(Math.random() * num.length);
    pass_baru += chars.charAt(i) + pass.charAt(j) + num.charAt(k);
  }
  return pass_baru;
}
