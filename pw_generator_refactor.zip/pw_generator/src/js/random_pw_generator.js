let resultEl = $("#pw-res");

let generate = $("#generate");

generate.on("click", function () {
  let inpLength = $(".inpLength:checked").val();
  let inpNumber = $("#inpNumber").val();
  let inpSymbols = $("#inpSymbol").val();

  if (inpLength == 8) {
    inpLength = inpLength - 5;
  } else if (inpLength == 16) {
    inpLength = inpLength - 11;
  }
  function randomPassword(length) {
    var chars = "abcdefghijklmnopqrstuvwxyz";
    var pass = "!@#$%^()_+<>?";
    var num = "123456789";
    var pass_baru = "";
    for (var x = 0; x < length; x++) {
      var i = Math.floor(Math.random() * (length + chars.length + 1));
      var j = Math.floor(Math.random() * pass.length - 1);
      var k = Math.floor(Math.random() * inpSymbols - 1);
      pass_baru += chars.charAt(i) + pass.charAt(j) + num.charAt(k);
    }
    return pass_baru;
  }

  let res = randomPassword(inpLength);

  resultEl.text(res);
});
